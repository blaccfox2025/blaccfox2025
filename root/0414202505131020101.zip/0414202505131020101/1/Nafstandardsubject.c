#define nafstandardsubject_origin
#ifdef nafstandardsubject_origin
typedef void Nafstandardsubject;
#endif

#define nafstandardsubject_export
#ifdef nafstandardsubject_export
#include <stdint.h>
#include <stdio.h>
#endif
