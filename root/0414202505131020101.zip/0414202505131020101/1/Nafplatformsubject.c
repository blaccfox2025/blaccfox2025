#define nafplatformsubject_origin
#ifdef nafplatformsubject_origin
typedef void Nafplatformsubject;
#endif
