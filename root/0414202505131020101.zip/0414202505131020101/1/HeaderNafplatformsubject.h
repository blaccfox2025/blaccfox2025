#define headerNafplatformsubject_origin
#ifdef headerNafplatformsubject_origin
typedef void HeaderNafplatformsubject;
#endif

#define WINDOW
