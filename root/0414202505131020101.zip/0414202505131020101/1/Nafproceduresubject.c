#define nafproceduresubject_origin
#ifdef nafproceduresubject_origin
typedef void Nafproceduresubject;
#endif
