#define ahmainprogram_origin
#ifdef ahmainprogram_origin
#include "Nafstandardsubject.c"
typedef void Ahmainprogram;
#endif
