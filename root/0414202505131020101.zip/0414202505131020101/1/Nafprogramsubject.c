#define nafprogramsubject_origin
#ifdef nafprogramsubject_origin
#include "Nafstandardsubject.c"
typedef void Nafprogramsubject;
#endif

#define nafprogramsubject_export
#ifdef nafprogramsubject_export
int32_t main
(
int32_t Numbernumeralnumericargument___integerselfargument___SELFARGUMENT,
const uint8_t** Argument________signnotintegerbyteotherpointerpointerargument________SIGNNOTINTEGERBYTEOTHERPOINTERPOINTERARGUMENT
);
void BaseAhmainprogram();
#endif
