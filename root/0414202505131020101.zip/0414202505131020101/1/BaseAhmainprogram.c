#include "Ahmainprogram.c"

void BaseAhmainprogram()
{
	printf("fff");

	return;
}
