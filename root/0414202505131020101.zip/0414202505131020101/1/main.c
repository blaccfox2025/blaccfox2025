#include "Nafprogramsubject.c"

int32_t main
(
int32_t Numbernumeralnumericargument___integerselfargument___SELFARGUMENT,
const uint8_t** Argument________signnotintegerbyteotherpointerpointerargument________SIGNNOTINTEGERBYTEOTHERPOINTERPOINTERARGUMENT
)
{
	int32_t integerResult = (int32_t){0};

	BaseAhmainprogram();

	int32_t* integerValuepointer;

	integerValuepointer = &(int32_t){0};

	integerResult = *integerValuepointer;

	return integerResult;
}
